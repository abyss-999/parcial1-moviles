package com.example.parcial1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.Serial;

public class MainActivity extends AppCompatActivity {

    private TextView saludos;
    private TextView datos;
    private EditText nombre;
    private EditText apellido;
    private Button entrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            saludos = findViewById(R.id.saludos);
            datos = findViewById(R.id.datos);
            nombre = findViewById(R.id.nombre);
            apellido = findViewById(R.id.apellido);
            entrar = findViewById(R.id.botonIn);

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
     saludos.setText("Saludos Bienvenido a la tienda Veira");
        datos.setText("Necesitamos estos dos datos para entrar :)");
        nombre.getText();
        apellido.getText();
    }
}