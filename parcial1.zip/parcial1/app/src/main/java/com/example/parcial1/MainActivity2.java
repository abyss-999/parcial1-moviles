package com.example.parcial1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private String input = "";
    private TextView titulo;
    private TextView nombretraido;
    private TextView apellidotraido;
    private TextView titulocomprar;
    private TextView cantidad;
    private Button tomate;
    private Button pera;
    private Button comprar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        titulo = findViewById(R.id.titulo);
        nombretraido = findViewById(R.id.nombretraido);
        apellidotraido = findViewById(R.id.apellidotraido);
        titulocomprar = findViewById(R.id.titulocomprar);
        comprar = findViewById(R.id.comprar);


        comprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });
        titulo.setText("Tienda Veira");
        titulocomprar.setText("Tenemos dos productos");
        nombretraido.setText("Santiago");
        apellidotraido.setText("Veira");
    }

    public void botones(View view) {
        Button boton = (Button) view;
        String numero = boton.getText().toString();

        if (input.equals("0")) {
            input = numero;
        } else {
            input += numero;
        }

        cantidad.setText(input);
    }
}